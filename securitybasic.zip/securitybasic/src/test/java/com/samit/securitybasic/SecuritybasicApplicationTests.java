package com.samit.securitybasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuritybasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
