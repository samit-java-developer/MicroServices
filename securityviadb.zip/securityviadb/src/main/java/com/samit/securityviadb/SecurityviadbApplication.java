package com.samit.securityviadb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityviadbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityviadbApplication.class, args);
	}

}
